---
name: API contract compatibility
description: OpenAPI integer fields need compatibility with the workspace's Zod generator setup.
---

When adding API schemas, prefer numeric fields unless the generated Zod output is verified against the installed Zod major version; this workspace currently emits `zod.int()` for OpenAPI integers, which is not available in its Zod 3 runtime.

**Why:** Codegen can succeed while the subsequent shared-library typecheck fails when generated helpers use APIs from a different Zod major version.

**How to apply:** Run API codegen and the shared-library typecheck immediately after OpenAPI changes, before wiring frontend hooks or server handlers.